package strategy;

public interface QuackBehavior {
	public void quack();
}
