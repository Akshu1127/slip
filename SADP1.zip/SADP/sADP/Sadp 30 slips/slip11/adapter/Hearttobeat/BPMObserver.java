package Hearttobeat;
  
public interface BPMObserver {
	void updateBPM();
}
