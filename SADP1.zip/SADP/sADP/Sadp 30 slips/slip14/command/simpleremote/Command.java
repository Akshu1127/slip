package simpleremote;


public interface Command 
{
	
	public void execute();

}
