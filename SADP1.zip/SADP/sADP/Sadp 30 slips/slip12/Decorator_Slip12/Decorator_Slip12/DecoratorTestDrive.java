import Decorator.*;
public class DecoratorTestDrive
{
	public static void main(String args[])
	{
		Car sportcar = new sportCar(new basicCar());
		sportcar.assemble();
		System.out.println();
		
		Car luxurycar = new luxuryCar(new basicCar());
		sportcar.assemble();
		System.out.println();
		
		Car sportluxurycar = new sportCar(new luxuryCar(new basicCar())); 
		sportluxurycar.assemble();
		System.out.println();
	}
}