package Decorator;
public class sportCar extends carDecorator
{
	
	public sportCar(Car c)
	{
		super(c);
	}
	public void assemble()
	{
		super.assemble();
		System.out.println("Adding Sport car Feature");
	}
}