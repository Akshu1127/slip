package Decorator;
public class carDecorator implements Car
{
	protected Car car;
	public carDecorator(Car c)
	{
		this.car=c;
	}
	public void assemble()
	{
		this.car.assemble();
	}
}