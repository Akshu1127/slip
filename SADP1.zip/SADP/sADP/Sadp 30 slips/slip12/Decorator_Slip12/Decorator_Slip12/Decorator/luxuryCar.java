package Decorator;
public class luxuryCar extends carDecorator
{
	
	public luxuryCar(Car c)
	{
		super(c);
	}
	public void assemble()
	{
		super.assemble();
		System.out.println("Adding Sport car Feature");
	}
}